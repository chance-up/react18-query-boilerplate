import ReactDOM from "react-dom/client";
import Root from "./routes/Root";
import "./index.css";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import { BasicMap } from "./routes/BasicMap";
import { MapWithMarker } from "./routes/MapWithMarker";
import { MapWithClustering } from "./routes/MapWithClustring";
import { GoogleMapComponent } from "./routes/GoogleMap";
import { GoogleMapMarker } from "./routes/GoogleMapWithMarker";
import { GoogleMapWithClustering } from "./routes/GoogleMapWithClustering";
import MapComponent from "./routes/test1";
import { GoogleMapEmbed } from "./routes/GoogleMapEmbed";

const router = createBrowserRouter([
  {
    path: "/",
    element: <Root />,
    children: [
      {
        path: "map",
        element: <BasicMap />,
      },
      {
        path: "marker",
        element: <MapWithMarker />,
      },
      {
        path: "cluster",
        element: <MapWithClustering />,
      },
      {
        path: "googleMap",
        element: <GoogleMapComponent />,
      },
      {
        path: "googleMapMarker",
        element: <GoogleMapMarker />,
      },
      {
        path: "googleMapCluster",
        element: <GoogleMapWithClustering />,
      },
      {
        path: "test1",
        element: <MapComponent />,
      },
      {
        path: "googleMapEmbed",
        element: <GoogleMapEmbed />,
      },
    ],
  },
]);
ReactDOM.createRoot(document.getElementById("root")!).render(
  <RouterProvider router={router} />
);
