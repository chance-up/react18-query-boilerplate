import Map from "react-map-gl";

export const BasicMap = () => {
  return (
    <div>
      {" "}
      <Map
        mapboxAccessToken="pk.eyJ1IjoiY2hhbmNldXAiLCJhIjoiY2xvY2dvbmJzMHlmbzJycjFxajk3ajVrMSJ9.gEYQFNDwYERWMKU6pI6piA"
        initialViewState={{
          longitude: 12.550343,
          latitude: 55.665957,
          zoom: 14,
        }}
        style={{ width: 600, height: 400 }}
        mapStyle="mapbox://styles/mapbox/streets-v12"
      ></Map>
    </div>
  );
};
