import { Outlet, NavLink } from "react-router-dom";

export default function Root() {
  return (
    <>
      <div id="sidebar">
        <nav>
          <ul>
            <li>
              <NavLink
                to={`map`}
                className={({ isActive, isPending }) =>
                  isActive ? "active" : isPending ? "pending" : ""
                }
              >
                Mapbox GL JS
              </NavLink>
            </li>
            <li>
              <NavLink
                to={`marker`}
                className={({ isActive, isPending }) =>
                  isActive ? "active" : isPending ? "pending" : ""
                }
              >
                Mapbox With Marker
              </NavLink>
            </li>
            <li>
              <NavLink
                to={`cluster`}
                className={({ isActive, isPending }) =>
                  isActive ? "active" : isPending ? "pending" : ""
                }
              >
                Mapbox With cluster
              </NavLink>
            </li>
            <li>
              <NavLink
                to={`googleMap`}
                className={({ isActive, isPending }) =>
                  isActive ? "active" : isPending ? "pending" : ""
                }
              >
                Google Map
              </NavLink>
            </li>
            <li>
              <NavLink
                to={`googleMapMarker`}
                className={({ isActive, isPending }) =>
                  isActive ? "active" : isPending ? "pending" : ""
                }
              >
                Google Map With Marker
              </NavLink>
            </li>
            <li>
              <NavLink
                to={`googleMapCluster`}
                className={({ isActive, isPending }) =>
                  isActive ? "active" : isPending ? "pending" : ""
                }
              >
                Google Map With Cluster
              </NavLink>
            </li>
            <li>
              <NavLink
                to={`googleMapEmbed`}
                className={({ isActive, isPending }) =>
                  isActive ? "active" : isPending ? "pending" : ""
                }
              >
                Google Map Embed(Iframe)
              </NavLink>
            </li>
            <li>
              <NavLink
                to={`test1`}
                className={({ isActive, isPending }) =>
                  isActive ? "active" : isPending ? "pending" : ""
                }
              >
                Test
              </NavLink>
            </li>
          </ul>
        </nav>
      </div>
      <div id="detail">
        {" "}
        <Outlet />
      </div>
    </>
  );
}
