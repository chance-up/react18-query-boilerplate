import React from "react";
import { GoogleMap, useJsApiLoader } from "@react-google-maps/api";

const containerStyle = {
  width: "800px",
  height: "800px",
};

const center = {
  lat: 37.56351829698907,
  lng: 126.82970672013136,
};

export const GoogleMapComponent = () => {
  const { isLoaded } = useJsApiLoader({
    id: "google-map-script",
    googleMapsApiKey: "AIzaSyCPDDsUNY9ArQC9TryEsOiyPzbqxK1urao",
  });

  const [map, setMap] = React.useState(null);

  //   const onLoad = React.useCallback(function callback(map: any) {
  // This is just an example of getting and using the map instance!!! don't just blindly copy!
  // const bounds = new window.google.maps.LatLngBounds(center);
  // map.fitBounds(bounds);
  // console.log(map);
  // setMap(map);
  //   }, []);

  const onUnmount = React.useCallback(function callback() {
    setMap(null);
  }, []);

  return isLoaded ? (
    <GoogleMap
      mapContainerStyle={containerStyle}
      center={center}
      zoom={18}
      onUnmount={onUnmount}
    >
      {/* Child components, such as markers, info windows, etc. */}
      <></>
    </GoogleMap>
  ) : (
    <></>
  );
};
