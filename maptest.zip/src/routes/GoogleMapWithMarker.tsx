import React from "react";
import { GoogleMap, useJsApiLoader, Marker } from "@react-google-maps/api";

const containerStyle = {
  width: "800px",
  height: "800px",
};

const center = {
  lat: 37.56351829698907,
  lng: 126.82970672013136,
};
const markerW6 = {
  lat: 37.563549186012295,
  lng: 126.82925956715953,
};

const markerE4 = {
  lat: 37.56329909584933,
  lng: 126.83235858023247,
};

export const GoogleMapMarker = () => {
  const { isLoaded } = useJsApiLoader({
    id: "google-map-script",
    googleMapsApiKey: "AIzaSyCPDDsUNY9ArQC9TryEsOiyPzbqxK1urao",
  });

  const [map, setMap] = React.useState(null);

  // const onLoad = React.useCallback(function callback(map: any) {
  //   const bounds = new window.google.maps.LatLngBounds(center);
  //   map.fitBounds(bounds);
  //   console.log(map);
  //   setMap(map);
  // }, []);

  const onUnmount = React.useCallback(function callback() {
    setMap(null);
  }, []);

  return isLoaded ? (
    <GoogleMap
      mapContainerStyle={containerStyle}
      center={center}
      zoom={18}
      onUnmount={onUnmount}
    >
      <Marker position={markerW6}></Marker>
      <Marker position={markerE4}></Marker>
    </GoogleMap>
  ) : (
    <></>
  );
};
