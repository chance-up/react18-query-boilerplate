export const GoogleMapEmbed = () => {
  return (
    <div>
      <iframe
        width="600"
        height="450"
        loading="lazy"
        src="https://www.google.com/maps/embed/v1/place?key=AIzaSyCPDDsUNY9ArQC9TryEsOiyPzbqxK1urao
    &q=Space+Needle,Seattle+WA"
      ></iframe>
    </div>
  );
};
