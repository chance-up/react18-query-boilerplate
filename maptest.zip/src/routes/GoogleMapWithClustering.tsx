import {
  GoogleMap,
  useJsApiLoader,
  Marker,
  MarkerClusterer,
} from "@react-google-maps/api";

const containerStyle = {
  width: "800px",
  height: "800px",
};

const center = {
  lat: 37.56351829698907,
  lng: 126.82970672013136,
};

export const GoogleMapWithClustering = () => {
  const { isLoaded } = useJsApiLoader({
    id: "google-map-script",
    googleMapsApiKey: "AIzaSyCPDDsUNY9ArQC9TryEsOiyPzbqxK1urao",
  });

  const locations = [
    { lat: 37.56315421042138, lng: 126.83343699097738 },
    { lat: 37.56096055228801, lng: 126.82889763451736 },
    { lat: 37.56375846256034, lng: 126.82603329431099 },
    { lat: 37.56111025313155, lng: 126.82049354451357 },
  ];

  const clusterOptions = {
    gridSize: 80,
    // maxZoom?: number | undefined;
    // zoomOnClick?: boolean | undefined;
    averageCenter: true,
    // minimumClusterSize?: number | undefined;
    // ignoreHidden?: boolean | undefined;
    // title?: string | undefined;
    // calculator?: TCalculator | undefined;
    // clusterClass?: string | undefined;
    // styles?: ClusterIconStyle[] | undefined;
    // enableRetinaIcons?: boolean | undefined;
    // batchSize?: number | undefined;
    // batchSizeIE?: number | undefined;
    imageExtension: "png",
    imagePath: "marker",
    // imageExtension?: string | undefined;
    // imageSizes?: number[] | undefined;
  };

  return isLoaded ? (
    <GoogleMap mapContainerStyle={containerStyle} center={center} zoom={18}>
      <MarkerClusterer options={clusterOptions}>
        {/* 아래 부분은 타입 관련 에러표기로 보임. 우선 무시 후 진행 */}
        {(clusterer) =>
          locations.map((location, index) => (
            <Marker key={index} position={location} clusterer={clusterer} />
          ))
        }
      </MarkerClusterer>
    </GoogleMap>
  ) : (
    <></>
  );
};
